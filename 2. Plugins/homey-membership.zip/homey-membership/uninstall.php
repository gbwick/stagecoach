<?php
defined('ABSPATH') || die('Nice Try Friend!');
/*
 * Here code for uninstall
 * */