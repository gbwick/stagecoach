<?php
//silence is golden in many cases