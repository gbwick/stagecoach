<?php
// silence is golden